package com.example.demotask.model

data class MovieResponse(val result: List<Movie>)
data class Movie(
    val id: String,
    val trailer_url: String,
    val title: String,
    val thumbnail: String,
    val banner: String,
    val description : String
)