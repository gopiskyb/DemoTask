package com.example.demotask.utils

import android.content.Context
import com.example.demotask.model.MovieResponse
import com.google.gson.Gson

fun loadJSONFromAsset(context: Context, filename: String): String {
    return context.assets.open(filename).bufferedReader().use { it.readText() }
}

fun parseMovieJson(jsonString: String): MovieResponse {
    return Gson().fromJson(jsonString, MovieResponse::class.java)
}